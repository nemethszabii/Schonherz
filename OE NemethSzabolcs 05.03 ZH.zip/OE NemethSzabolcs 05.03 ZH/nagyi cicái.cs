﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace nagymama
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            kep1.Visible = false;
            kep2.Visible = false;
            kep3.Visible = false;
            kep4.Visible = false;
            kep5.Visible = false;
            kep6.Visible = false;
            kep7.Visible = false;
            kep8.Visible = false;
            kep9.Visible = false;
            kep10.Visible = false;
        }

        private void kilepes_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void gomb1_Click(object sender, EventArgs e)
        {
            kep1.Visible = true;
            kep2.Visible = false;
            kep3.Visible = false;
            kep4.Visible = false;
            kep5.Visible = false;
            kep6.Visible = false;
            kep7.Visible = false;
            kep8.Visible = false;
            kep9.Visible = false;
            kep10.Visible = false;
        }

        private void gomb2_Click(object sender, EventArgs e)
        {
            kep2.Visible = true;
            kep1.Visible = false;
            kep3.Visible = false;
            kep4.Visible = false;
            kep5.Visible = false;
            kep6.Visible = false;
            kep7.Visible = false;
            kep8.Visible = false;
            kep9.Visible = false;
            kep10.Visible = false;
        }

        private void kep6_Click(object sender, EventArgs e)
        {
            //nem kell
        }

        private void gomb3_Click(object sender, EventArgs e)
        {
            kep1.Visible = false;
            kep2.Visible = false;
            kep3.Visible = true;
            kep4.Visible = false;
            kep5.Visible = false;
            kep6.Visible = false;
            kep7.Visible = false;
            kep8.Visible = false;
            kep9.Visible = false;
            kep10.Visible = false;
        }

        private void gomb4_Click(object sender, EventArgs e)
        {
            kep1.Visible = false;
            kep2.Visible = false;
            kep3.Visible = false;
            kep4.Visible = true;
            kep5.Visible = false;
            kep6.Visible = false;
            kep7.Visible = false;
            kep8.Visible = false;
            kep9.Visible = false;
            kep10.Visible = false;
        }

        private void gomb5_Click(object sender, EventArgs e)
        {
            kep1.Visible = false;
            kep2.Visible = false;
            kep3.Visible = false;
            kep4.Visible = false;
            kep5.Visible = true;
            kep6.Visible = false;
            kep7.Visible = false;
            kep8.Visible = false;
            kep9.Visible = false;
            kep10.Visible = false;
        }

        private void gomb6_Click(object sender, EventArgs e)
        {
            kep1.Visible = false;
            kep2.Visible = false;
            kep3.Visible = false;
            kep4.Visible = false;
            kep5.Visible = false;
            kep6.Visible = true;
            kep7.Visible = false;
            kep8.Visible = false;
            kep9.Visible = false;
            kep10.Visible = false;
        }

        private void gomb7_Click(object sender, EventArgs e)
        {
            kep1.Visible = false;
            kep2.Visible = false;
            kep3.Visible = false;
            kep4.Visible = false;
            kep5.Visible = false;
            kep6.Visible = false;
            kep7.Visible = true;
            kep8.Visible = false;
            kep9.Visible = false;
            kep10.Visible = false;
        }

        private void gomb8_Click(object sender, EventArgs e)
        {
            kep1.Visible = false;
            kep2.Visible = false;
            kep3.Visible = false;
            kep4.Visible = false;
            kep5.Visible = false;
            kep6.Visible = false;
            kep7.Visible = false;
            kep8.Visible = true;
            kep9.Visible = false;
            kep10.Visible = false;
        }

        private void gomb9_Click(object sender, EventArgs e)
        {
            kep1.Visible = false;
            kep2.Visible = false;
            kep3.Visible = false;
            kep4.Visible = false;
            kep5.Visible = false;
            kep6.Visible = false;
            kep7.Visible = false;
            kep8.Visible = false;
            kep9.Visible = true;
            kep10.Visible = false;
        }

        private void gomb10_Click(object sender, EventArgs e)
        {
            kep1.Visible = false;
            kep2.Visible = false;
            kep3.Visible = false;
            kep4.Visible = false;
            kep5.Visible = false;
            kep6.Visible = false;
            kep7.Visible = false;
            kep8.Visible = false;
            kep9.Visible = false;
            kep10.Visible = true;
        }
    }
}
