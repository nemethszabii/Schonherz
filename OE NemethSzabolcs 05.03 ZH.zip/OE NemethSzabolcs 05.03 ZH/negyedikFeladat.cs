﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace negyedikFeladat
{
    public partial class Form1 : Form
    {
        int szam1 = 0;
        int szam2 = 0;
        int eredmeny = 0;
        Random r1 = new Random();
        Random r2 = new Random();
        int helyesValasz = 0;
        int probaSzam = 0;


        public Form1()
        {
            InitializeComponent();
            visszajelzo.Visible = false;
            szam1 = r1.Next(50,100);
            szam2 = r1.Next(0, 10);
            eredmeny = szam1 / szam2;
            felirat1.Text = Convert.ToString(szam1);
            felirat2.Text = Convert.ToString(szam2);
            helyesKiir.Text = helyesValasz.ToString();
            eddigiProba.Text = probaSzam.ToString();
            if (szam1 % szam2 != 0)
            {
                szam2 = r1.Next(0, 10);
            }
            if (probaSzam == 10)
            {
                visszajelzo.Visible = true;
                visszajelzo.Text = "Vége a Játéknak!";
            }
        }

        private void kilepes_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void felirat1_Click(object sender, EventArgs e)
        {
            //nem kell
        }

        private void ellenorzo_Click(object sender, EventArgs e)
        {
            eredmeny = szam1 / szam2;
            if (valasz.Text == eredmeny.ToString())
            {
                visszajelzo.Text = "Helyes válasz";
                visszajelzo.Visible = true;
                helyesValasz++;
                helyesKiir.Text = helyesValasz.ToString();
            }
            if (valasz.Text != eredmeny.ToString())
            {
                visszajelzo.Text = "Sajnos nem jó";
                visszajelzo.Visible = true;
            }
            if (probaSzam==10)
            {
                visszajelzo.Text = "Vége a Játéknak!";
            }
        }

        private void ujra_Click(object sender, EventArgs e)
        {
            visszajelzo.Visible = false;
            szam1 = r2.Next(50, 100);
            szam2 = r2.Next(0, 10);
            eredmeny = szam1 / szam2;
            valasz.Text = "";
            probaSzam++;
            eddigiProba.Text = probaSzam.ToString();
            felirat1.Text = Convert.ToString(szam1);
            felirat2.Text = Convert.ToString(szam2);
            if (probaSzam == 10)
            {
                visszajelzo.Visible = true;
                visszajelzo.Text = "Vége a Játéknak!";
            }
        }
    }
}
