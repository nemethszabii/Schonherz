﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ugyfelportal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            string nevBeir = Convert.ToString(nev.Text);
            string nemBeir = Convert.ToString(neme.Text);
            string emailBeir = Convert.ToString(email.Text);
            string telszamBeir = Convert.ToString(telszam.Text);
            felirat5.Visible = false;
            felirat6.Visible = false;
            felirat7.Visible = false;
            felirat8.Visible = false;
            nevKiir.Visible = false;
            nemKiir.Visible = false;
            emailKiir.Visible = false;
            telszamKiir.Visible = false;
            jovahagy.Visible = false;
            kerdes.Visible = false;
            kiirasEllenorzo.Visible = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //nem kell
        }

        private void kilepes_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ellenorzes_Click(object sender, EventArgs e)
        {
            ellenorzes.Visible = false;
            felirat1.Visible = false;
            felirat2.Visible = false;
            felirat3.Visible = false;
            felirat4.Visible = false;
            nev.Visible = false;
            neme.Visible = false;
            email.Visible = false;
            telszam.Visible = false;
            felirat5.Visible = true;
            felirat6.Visible = true;
            felirat7.Visible = true;
            felirat8.Visible = true;
            nevKiir.Visible = true;
            nemKiir.Visible = true;
            emailKiir.Visible = true;
            telszamKiir.Visible = true;
            jovahagy.Visible = true;
            kerdes.Visible = true;
            string nevBeir = Convert.ToString(nev.Text);
            string nemBeir = Convert.ToString(neme.Text);
            string emailBeir = Convert.ToString(email.Text);
            string telszamBeir = Convert.ToString(telszam.Text);
            nevKiir.Text = nevBeir;
            nemKiir.Text = nemBeir;
            emailKiir.Text = emailBeir;
            telszamKiir.Text = Convert.ToString(telszamBeir);
        }

        private void jovahagy_Click(object sender, EventArgs e)
        {
            kiirasEllenorzo.Visible = true;
            string nevBeir = Convert.ToString(nev.Text);
            string nemBeir = Convert.ToString(neme.Text);
            string emailBeir = Convert.ToString(email.Text);
            int telszamBeir = Convert.ToInt32(telszam.Text);
            string fajlnev = "ugyfelfeladat.txt";
            StreamWriter kiir = new StreamWriter(fajlnev);
            kiir.WriteLine(nevBeir);
            kiir.WriteLine(nemBeir);
            kiir.WriteLine(emailBeir);
            kiir.WriteLine(telszamBeir);
            kiir.Close();

        }
    }
}
