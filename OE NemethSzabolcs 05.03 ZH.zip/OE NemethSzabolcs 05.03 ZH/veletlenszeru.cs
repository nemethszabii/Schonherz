﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace veletlenszeru
{
    public partial class Form1 : Form
    {
        int szam = 0;
        int szam2 = 0;
        int szam3 = 0;
        int szam4 = 0;
        int szam5 = 0;
        int szam6 = 0;
        int szam7 = 0;
        public Form1()
        {
            InitializeComponent();
            elso.Visible = false;
            masodik.Visible = false;
            harmadik.Visible = false;
            negyedik.Visible = false;
            otodik.Visible = false;
            hatodik.Visible = false;
            hetedik.Visible = false;
        }

        private void kilepes_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void kiiratas_Click(object sender, EventArgs e)
        {
            elso.Visible = true;
            masodik.Visible = true;
            harmadik.Visible = true;
            negyedik.Visible = true;
            otodik.Visible = true;
            hatodik.Visible = true;
            hetedik.Visible = true;
            Random r1 = new Random();
            if (szam == szam2 || szam == szam3 || szam == szam4 || szam == szam5 || szam == szam6 || szam == szam7)
            {
                szam = r1.Next(1, 46);
            }
            if (szam2 == szam || szam2 == szam3 || szam2 == szam4 || szam2 == szam5 || szam2 == szam6 || szam2 == szam7)
            {
                szam2 = r1.Next(1, 46);
            }
            if (szam3 == szam || szam3 == szam2 || szam3 == szam4 || szam3 == szam5 || szam3 == szam6 || szam3 == szam7)
            {
                szam3 = r1.Next(1, 46);
            }
            if (szam4 == szam || szam4 == szam2 || szam4 == szam3 || szam4 == szam5 || szam4 == szam6 || szam4 == szam7)
            {
                szam4 = r1.Next(1, 46);
            }
            if (szam5 == szam2 || szam5 == szam3 || szam5 == szam4 || szam5 == szam || szam5 == szam6 || szam5 == szam7)
            {
                szam5 = r1.Next(1, 46);
            }
            if (szam6 == szam2 || szam6 == szam3 || szam6 == szam4 || szam6 == szam5 || szam6 == szam || szam6 == szam7)
            {
                szam6 = r1.Next(1, 46);
            }
            if (szam7 == szam2 || szam7 == szam3 || szam7 == szam4 || szam7 == szam5 || szam7 == szam6 || szam7 == szam)
            {
                szam7 = r1.Next(1, 46);
            }
            elso.Text = szam.ToString();
            masodik.Text = szam2.ToString();
            harmadik.Text = szam3.ToString();
            negyedik.Text = szam4.ToString();
            otodik.Text = szam5.ToString();
            hatodik.Text = szam6.ToString();
            hetedik.Text = szam7.ToString();
            int[] tomb = new int[7];
            tomb[0] = szam;
            tomb[1] = szam2;
            tomb[2] = szam3;
            tomb[3] = szam4;
            tomb[4] = szam5;
            tomb[5] = szam6;
            tomb[6] = szam7;
            //for (int i = 0; i <= tomb.Length-1; i++)
            //{
            //    elso.Text = Convert.ToString(tomb[i]);
            //}
            Array.Sort(tomb);
        }
    }
}
